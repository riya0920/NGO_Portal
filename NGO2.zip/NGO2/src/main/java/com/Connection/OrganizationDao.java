package com.Connection;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class OrganizationDao {
	public int addOrg(OrganizatioBean ob) {
		String insertQ = "INSERT INTO ORGANIZATIONS (ORG_ID,ORG_NAME,USERNAME,PASSWORD) VALUES ('"+ob.getOid()+"','"+ob.getOname()+"','"+ob.getUname()+"', ' ', '"+ob.getPass()+"', ' ')";
		Connection conn = DbConnection.getDbConnection();
		Statement stmt = null;
		int rows = 0;
		if (conn != null)
		{
			try {
				stmt = conn.createStatement();
				rows = stmt.executeUpdate(insertQ);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("Error caught");
			}
		
			
		}
		System.out.println("IN addOrg!");
		System.out.println(rows);
		return rows;
	}

	public boolean checkLogin(String uname, String pass) {
		String dispQ = "SELECT * FROM ORGANIZATIONS WHERE USERNAME = "+ "'"+uname+"'" + "AND PASSWORD = "+"'"+pass+"'";
		Connection conn = DbConnection.getDbConnection();
		Statement stmt = null;
		String username = null, password = null;
//		List<Employeebean> list = new ArrayList<Employeebean>();
		int rows = 0;
		if (conn != null)
		{
			try {
				stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(dispQ);
				while (rs.next()) {
	                
	                /*Retrieve one employee details 
	                and store it in employee object*/
	                username = rs.getString("USERNAME");
	                password = rs.getString("PASSWORD");
	                //add each employee to the list
//	                list.add(eb);
				
			} }catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (uname.equals(username) && pass.equals(password)) {
				return true;
			}
			else
			{
				return false;
			}
		
			
		}
		System.out.println("IN checkLogin!");
		return false;
		
	}
	public int applyEvent(String eid,String org_uname) {
		String retrieveQ = "SELECT EVENT_VACANCY FROM EVENTS WHERE EID = '"+ eid + "';";
		String updateQ = "UPDATE EVENTS SET EVENT_VACANCY = EVENT_VACANCY-1 WHERE EID = '"+ eid + "';";
		Connection conn = DbConnection.getDbConnection();
		Statement stmt = null;
		int rows = 0;
		if (conn != null)
		{
			try {
				stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(retrieveQ);
				while (rs.next()) {
	                
	                /*Retrieve one employee details 
	                and store it in employee object*/
					int vacancy = rs.getInt(1);
					if(vacancy == 0) {
						OrganizationDao od = new OrganizationDao();
						od.deleteEvent(eid,org_uname);
					}
					else {
						rows = stmt.executeUpdate(updateQ);
					}
			}} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("Error caught");
			}
		
			
		}
		System.out.println("IN addEvent!");
		System.out.println(rows);
		return rows;		
	}
	
	public void changePhase(int Phase,String eid) {
		String updateQ = "UPDATE EVENTS SET PHASE = " + Phase + " WHERE EID = '" + eid + "';";
		if (Phase == 3) {
			
		}
		Connection conn = DbConnection.getDbConnection();
		Statement stmt = null;
		int rows = 0;
		if (conn != null)
		{
			try {
				stmt = conn.createStatement();
				rows = stmt.executeUpdate(updateQ);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("Error caught");
			}
		
			
		}
	}
	public int addEvent(EventBean eb,String uname) {
		String insertQ = "INSERT INTO EVENTS VALUES ('"+eb.getEid()+"','"+eb.getEname()+"','"+eb.getEvac()+"',"+eb.getHours()+",'"+eb.getLoc()+"','"+eb.getDesc()+"',"+1+")";
		String updateQ = "UPDATE ORGANIZATIONS SET PRESENT_EVENT = '" + eb.getEid()+"' WHERE USERNAME = '"+uname+"';";
		Connection conn = DbConnection.getDbConnection();
		Statement stmt = null;
		Statement stmt2 = null;
		int rows = 0,rows2 = 0;
		if (conn != null)
		{
			try {
				stmt = conn.createStatement();
				stmt2 = conn.createStatement();
				rows = stmt.executeUpdate(insertQ);
				rows2 = stmt2.executeUpdate(updateQ);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("Error caught");
			}
		
			
		}
		System.out.println("IN addEvent!");
		System.out.println(rows);
		System.out.println(rows2);
		return rows;
	}

	public void deleteEvent(String eid,String org_uname) {

		String dispQ = "UPDATE ORGANIZATIONS SET PAST_EVENTS = CONCAT(PAST_EVENTS,"+"' ','" +eid+"') WHERE USERNAME = '"+org_uname+"';";
		String q = "UPDATE ORGANIZATIONS SET PRESENT_EVENT = '' WHERE USERNAME = '" + org_uname + "'";
		String query = "UPDATE EVENTS SET PHASE = " + 2 + " WHERE EID = '"+eid+"'";
		Connection conn = DbConnection.getDbConnection();
		Statement stmt = null;
		
		if (conn != null)
		{
			try {
				stmt = conn.createStatement();
				int rows = stmt.executeUpdate(dispQ);
				int rows1 = stmt.executeUpdate(q);
				int rows2 = stmt.executeUpdate(query);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}	
	}
	
}
